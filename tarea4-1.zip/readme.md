# Este es mi archivo readme

Este archivo se escribe en formato markdown.

## Propósito del proyecto

Este es un proyecto didáctico en el que vamos a crear una API REST.
