// Importamos las bibliotecas necesarias.
// Concretamente el framework express.
const { MongoClient, ServerApiVersion, ObjectId } = require('mongodb');
const express = require("express");
//const cliente = require("./utils");
// Swagger
const swaggerUi = require("swagger-ui-express");
const swaggerDocument = require("./swagger.json");
// Inicializamos la aplicación
const app = express();
app.use(express.json());
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Indicamos el puerto en el que vamos a desplegar la aplicación
const port = process.env.DB_PORT || 8080;
// Base de datos y colección
let db;

//const uri = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PASSWORD}@cluster0.uskv7.mongodb.net/?retryWrites=true&w=majority`;
const uri = "mongodb://localhost:27017/";

const cliente = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
});
// Inicializar la conexión con MongoDB al arrancar la app
cliente
  .connect()
  .then(() => {
    db = cliente.db("greidslas");
    greidslasCollection = db.collection("greidslas");
    console.log("Conexión exitosa a MongoDB");
  })
  .catch((err) => console.error("Error conectando a MongoDB:", err));
// Arrancamos la aplicación
app.listen(port, () => {
  console.log(`Servidor desplegado en puerto: ${port}`);
});

// Lista todos los concesionarios
app.get("/greidslas", async (request, response) => {
  try {
    await cliente.connect(); // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas"); // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas"); // Nombre de la colección
    const greidslas = await greidslasCollection.find().toArray(); // Obtener todos los greidslas
    response.json(greidslas); // Enviar los concesionarios como respuesta
  } catch (err) {
    console.error("Error al obtener los greidslas:", err);
    response.status(500).json({ error: "Error al obtener greidslas" }); // Enviar error si algo falla
  } finally {
    await cliente.close(); // Cerrar la conexión
  }
});

// Añadir un nuevo concesionario
app.post("/greidslas", async (request, response) => {
  const nuevoGreidsla = request.body; // Obtener el nuevo concesionario desde el cuerpo de la solicitud

  try {
    await cliente.connect(); // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas"); // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas"); // Nombre de la colección

    // Insertar el nuevo concesionario en la base de datos
    await greidslasCollection.insertOne(nuevoGreidsla);
    // Enviar respuesta con el mensaje de éxito y el concesionario insertado
    response.json({message: "greidsla agregado"});
    
  } catch (err) {
    console.error("Error al agregar el greidsla:", err);
    response.status(500).json({ error: "Error al agregar greidsla" }); // Enviar error si algo falla
  } finally {
    await cliente.close(); // Cerrar la conexión
  }
});

// Obtener un solo concesionario
app.get("/greidslas/:id", async (request, response) => {
  const { id } = request.params; // Obtener el id desde los parámetros de la URL
  try {
    await cliente.connect(); // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas"); // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas"); // Nombre de la colección

    // Buscar el concesionario por su _id
    const greidsla = await greidslasCollection.findOne({
      _id: new ObjectId(id),
    });

    if (greidsla) {
      response.json({ greidsla }); // Enviar el concesionario encontrado
    } else {
      response.status(404).json({ error: "greidsla no encontrado" }); // Si no se encuentra, enviar error 404
    }
  } catch (err) {
    console.error("Error al obtener el greidsla:", err);
    response.status(500).json({ error: "Error al obtener el greidsla" }); // Enviar error si algo falla
  } finally {
    await cliente.close(); // Cerrar la conexión
  }
});

// Actualizar un solo concesionario
app.put("/greidslas/:id", async (request, response) => {
  const { id } = request.params;  // Obtener el id desde los parámetros de la URL
  const actualizarGreidsla = request.body;  // Obtener el nuevo concesionario desde el cuerpo de la solicitud
  try {
    await cliente.connect();  // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas");  // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas");  // Nombre de la colección

    // Buscar el concesionario por su _id y actualizarlo
    const result = await greidslasCollection.updateOne(
      { _id: new ObjectId(id) },  // Filtrar por _id
      { $set: actualizarGreidsla }  // Actualizar los campos con los datos recibidos
    );

    // Verificar si se realizó la actualización
    if (result.modifiedCount > 0) {
      response.json({ message: "greidsla actualizado", concesionario: actualizarGreidsla });
    } else {
      response.status(404).json({ error: "greidsla no encontrado" });  // Si no se encuentra, enviar error 404
    }
  } catch (err) {
    console.error("Error al actualizar el greidsla:", err);
    response.status(500).json({ error: "Error al actualizar el greidsla" });  // Enviar error si algo falla
  } finally {
    await cliente.close();  // Cerrar la conexión
  }
});


// Borrar un concesionario
app.delete("/greidslas/:id", async(request, response) => {
  const { id } = request.params; // Obtener el id desde los parámetros de la URL
  try {
    await cliente.connect(); // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas"); // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas"); // Nombre de la colección

    // Buscar el concesionario por su _id
    const greidsla = await greidslasCollection.deleteOne({
      _id: new ObjectId(id),
    });

    if (greidsla) {
      response.json({ greidsla }); // Enviar el concesionario encontrado
    } else {
      response.status(404).json({ error: "greidsla no encontrado" }); // Si no se encuentra, enviar error 404
    }
  } catch (err) {
    console.error("Error al obtener el greidsla:", err);
    response.status(500).json({ error: "Error al obtener el greidsla" }); // Enviar error si algo falla
  } finally {
    await cliente.close(); // Cerrar la conexión
  }
});
// listaConcesionarios de un concesionario
app.get("/greidslas/:id/puckets", async (request, response) => {
  const id = request.params.id;  // Obtener el id desde los parámetros de la URL

  try {
    await cliente.connect();  // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas");  // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas");  // Nombre de la colección

    // Buscar el concesionario por _id
    const greidsla = await greidslasCollection.findOne({ _id: new ObjectId(id) });

    if (greidsla) {
      // Si el concesionario existe, devolver solo la lista de coches
      response.json(greidsla.listaCoches);
    } else {
      // Si no se encuentra el concesionario, devolver error
      response.status(404).json({ error: "greidsla no encontrado" });
    }
  } catch (err) {
    console.error("Error al obtener los pucket:", err);
    response.status(500).json({ error: "Error al obtener los pucket" });
  } finally {
    await cliente.close();  // Cerrar la conexión
  }
});

// Añadir un nuevo coche al concesionario pasado por id
app.post("/greidslas/:id/puckets", async (request, response) => {
  const id = request.params.id;  // Obtener el id desde los parámetros de la URL
  const nuevoPucket = request.body;  // Obtener los datos del coche a añadir

  try {
    await cliente.connect();  // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas");  // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas");  // Nombre de la colección

    // Actualizar el concesionario con el nuevo coche
    const result = await greidslasCollection.insertOne(
      { _id: new ObjectId(id) },  // Filtrar por _id
      { $push: { listaPuckets: nuevoPucket } }  // Agregar el nuevo coche a la listaCoches
    );

    if (result.modifiedCount === 1) {
      // Si se modificó al menos un documento (es decir, el concesionario fue encontrado y actualizado)
      response.json({ message: "pucket añadido", concesionarioId: id });
    } else {
      // Si no se encuentra el concesionario con ese id
      response.status(404).json({ error: "greidsla no encontrado" });
    }
  } catch (err) {
    console.error("Error al añadir el pucket:", err);
    response.status(500).json({ error: "Error al añadir el pucket" });
  } finally {
    await cliente.close();  // Cerrar la conexión
  }
});

// Obtiene el coche cuyo índice sea cocheId, del concesionario pasado por id
app.get("/greidslas/:id/puckets/:pucketId", async (request, response) => {
  const id = request.params.id;  // Obtener el id del concesionario
  const pucketId = parseInt(request.params.cocheId, 10);  // Obtener el id del coche (convertido a número entero)

  try {
    await cliente.connect();  // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas");  // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas");  // Nombre de la colección

    // Buscar el concesionario por su _id
    const greidsla = await greidslasCollection.findOne({ _id: new ObjectId(id) });

    if (!greidsla) {
      return response.status(404).json({ error: "greidsla no encontrado" });  // Si no se encuentra el concesionario
    }

    // Verificar si la posición de cocheId existe en la lista de coches
    if (pucketId >= 0 && pucketId < greidsla.listaPuckets.length) {
      const pucket = greidsla.listaPuckets[pucketId];  // Obtener el coche por índice
      response.json({ pucket });  // Enviar la respuesta con el coche encontrado
    } else {
      response.status(404).json({ error: "pucket no encontrado" });  // Si no se encuentra el coche
    }
  } catch (err) {
    console.error("Error al obtener el pucket:", err);
    response.status(500).json({ error: "Error al obtener el pucket" });  // Enviar error si algo falla
  } finally {
    await cliente.close();  // Cerrar la conexión
  }
});



// Actualiza el coche cuyo id sea cocheId, del concesionario pasado por id
app.put("/greidslas/:id/puckets/:pucketId", async (request, response) => {
  const greidslaId = request.params.id;  // ID del concesionario
  const pucketId = parseInt(request.params.pucketId, 10);  // ID del coche (índice en el array de coches)
  const updatedPucket = request.body;  // Nuevo coche con los datos a actualizar

  try {
    await cliente.connect();  // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas");  // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas");  // Nombre de la colección

    // Buscar el concesionario por su _id
    const greidsla = await greidslasCollection.findOne({ _id: new ObjectId(greidslaId) });

    if (!greidsla) {
      return response.status(404).json({ error: "greidsla no encontrado" });  // Si no se encuentra el concesionario
    }

    // Verificar si el cocheId existe dentro de la lista de coches
    if (pucketId >= 0 && pucketId < greidsla.listaPuckets.length) {
      // Actualizar el coche en la posición indicada
      greidsla.listaPuckets[pucketId] = updatedPucket;

      // Actualizar el concesionario en la base de datos con el coche modificado
      const result = await greidslasCollection.updateOne(
        { _id: new ObjectId(greidslaId) },
        { $set: { listaPuckets: greidsla.listaPuckets } }
      );

      if (result.modifiedCount > 0) {
        response.json({
          message: "pucket actualizado correctamente",
          greidsla: greidsla.listaPuckets[pucketId],
        });
      } else {
        response.status(500).json({ error: "No se pudo actualizar el pucket" });
      }
    } else {
      response.status(404).json({ error: "pucket no encontrado" });  // Si el coche no existe en la lista
    }
  } catch (err) {
    console.error("Error al actualizar el pucket:", err);
    response.status(500).json({ error: "Error al actualizar el pucket" });  // Enviar error si algo falla
  } finally {
    await cliente.close();  // Cerrar la conexión
  }
});


// Borra el coche cuyo id sea cocheId, del concesionario pasado por id
app.delete("/greidslas/:id/puckets/:pucketId", async (request, response) => {
  const greidslaId = request.params.id;  // ID del concesionario
  const pucketId = parseInt(request.params.pucketId, 10);  // ID del coche (índice en el array de coches)

  try {
    await cliente.connect();  // Conectar al servidor de MongoDB
    const database = cliente.db("greidslas");  // Nombre de la base de datos
    const greidslasCollection = database.collection("greidslas");  // Nombre de la colección

    // Buscar el concesionario por su _id
    const greidsla = await greidslasCollection.findOne({ _id: new ObjectId(greidslaId) });

    if (!greidsla) {
      return response.status(404).json({ error: "greidsla no encontrado" });  // Si no se encuentra el concesionario
    }

    // Verificar si el cocheId existe dentro de la lista de coches
    if (pucketId >= 0 && pucketId < greidsla.listaPuckets.length) {
      // Eliminar el coche de la lista
      greidsla.listaPuckets.splice(pucketId, 1);

      // Actualizar el concesionario en la base de datos con el coche eliminado
      const result = await greidslasCollection.updateOne(
        { _id: new ObjectId(greidslaId) },
        { $set: { listaPuckets: greidsla.listaPuckets } }
      );

      if (result.modifiedCount > 0) {
        response.json({
          message: "pucket eliminado correctamente",
          greidsla: greidsla.listaPuckets,
        });
      } else {
        response.status(500).json({ error: "No se pudo eliminar el pucket" });
      }
    } else {
      response.status(404).json({ error: "pucket no encontrado" });  // Si el coche no existe en la lista
    }
  } catch (err) {
    console.error("Error al eliminar el pucket:", err);
    response.status(500).json({ error: "Error al eliminar el pucket" });  // Enviar error si algo falla
  } finally {
    await cliente.close();  // Cerrar la conexión
  }
});